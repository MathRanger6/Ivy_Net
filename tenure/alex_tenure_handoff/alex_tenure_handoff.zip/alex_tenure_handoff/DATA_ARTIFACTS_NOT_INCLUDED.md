# External resources (not in zip)

**Full map + access options:** **`RIVANNA_DATA_PATHS.md`**

Charles's complete checkpoint is on Rivanna at:

```text
/sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/tenure/tenure_pipeline/
```

**Alex does not automatically have read access** to the `dzk3ja/` home directory. Charles and Alex will decide later whether to share permissions, copy a subset, rsync, or have Alex rebuild from the handoff code.

**In zip:** `examples/*.sample` (schema reference) + all code and small config.

Also external: UVA CDH OpenAlex snapshot (`~/cdh/OpenAlex1125/`) — separate UVA access request.
