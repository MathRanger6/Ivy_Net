# Example files — schema reference only

These files are **truncated samples** for understanding data shape. **Do not** point CELL 0 at `examples/` for production runs.

**Full data:** see **`RIVANNA_DATA_PATHS.md`** (Charles's tree on UVA Rivanna).

## How to inspect a sample

```bash
head -3 examples/faculty_panel_with_pools.jsonl.sample | python3 -m json.tool
```

## Sample → production path mapping

| Sample in `examples/` | Production file on Rivanna |
|-----------------------|----------------------------|
| `faculty_snapshots_plan.jsonl.sample` | `.../tenure/tenure_pipeline/faculty_snapshots_plan.jsonl` |
| `faculty_snapshots_parsed.jsonl.sample` | `.../tenure/tenure_pipeline/faculty_snapshots_parsed.jsonl` |
| `faculty_panel_with_pools.jsonl.sample` | `.../tenure/tenure_pipeline/faculty_panel_with_pools.jsonl` |
| `openalex_author_ids.jsonl.sample` | `.../tenure/tenure_pipeline/openalex_author_ids.jsonl` |
| `faculty_snapshots/**/*.html` | `.../tenure/tenure_pipeline/faculty_snapshots/` (33K+ files) |
| `R1_tenure_data.csv.sample` | `.../tenure/tenure_pipeline/R1_tenure_data.csv` |

Replace `...` with `/sfs/gpfs/tardis/home/dzk3ja/Ivy_Net` (or symlink — see RIVANNA_DATA_PATHS.md).
