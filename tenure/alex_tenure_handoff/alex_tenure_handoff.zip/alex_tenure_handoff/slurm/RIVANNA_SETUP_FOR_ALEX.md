# Rivanna setup for Alex Gates

**Read this before your first `sbatch`.** Every Slurm script in this handoff still contains Charles's UVA account defaults until you edit them.

---

## 1. Unzip and choose workspace root

After unzipping, you should have one folder (e.g. `alex_tenure_handoff/`) that contains **`functionsG_working.py`** at its top level.

```bash
cd /path/to/alex_tenure_handoff
ls functionsG_working.py tenure/540_tenure_pipeline.ipynb   # both must exist
```

**Full data is NOT in the zip.** Charles's checkpoint lives at `/sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/tenure/tenure_pipeline/` — **Alex may not have access yet.** Read **`RIVANNA_DATA_PATHS.md`** for the file catalog and Options A–D (permissions, copy, rsync, rebuild). Do not symlink until Charles confirms access.

---

## 2. Slurm fields you MUST change

Edit **every** `#SBATCH` block in these files:

| File | Purpose |
|------|---------|
| `slurm/myjob.slurm` | One-time conda env create/update |
| `pipe_job.slurm` | Batch-run `540_tenure_pipeline.ipynb` via papermill |
| `build_openalex_cache.slurm` | Bulk OpenAlex works-by-year cache (Rivanna CDH) |

### Replace these two lines in each file

```bash
#SBATCH --mail-user=YOUR_UVA_EMAIL@virginia.edu    # was: dzk3ja@virginia.edu
#SBATCH --account=YOUR_ALLOCATION                  # was: sds_ag
```

### Optional adjustments

| Directive | Default | When to change |
|-----------|---------|----------------|
| `--partition` | `standard` | If your allocation uses a different queue |
| `--constraint` | `rivanna` | Remove only if your cluster docs say so |
| `--time` | 2–12 h | Increase for full notebook or OA cache build |
| `--mem` | 32–64G | `pipe_job` uses 64G; OA cache uses 32G |

### Watch commands — update username

In `pipe_job.slurm` comment block, replace `squeue -u dzk3ja` with **`squeue -u YOUR_USERNAME`**.

---

## 3. Recommended first-time Rivanna sequence

```bash
cd ~/tenure_handoff          # workspace root
mkdir -p slurm_out

# Step A — conda environment (once)
sbatch slurm/myjob.slurm
# Watch: tail -f slurm_out/slurm-tenure_net_env_install-*.out

# Step B — optional: extra pip pins (papermill for pipe_job)
# Copy myjob.local.sh.example → myjob.local.sh, re-run myjob.slurm, OR:
conda activate tenure_net
pip install papermill

# Step C — OpenAlex CDH snapshot path (NOT in this zip)
# Request/mount UVA CDH OpenAlex tree, typically:
#   ~/cdh/OpenAlex1125/
# Then build cache (3–8 hours first run):
sbatch build_openalex_cache.slurm

# Step D — full pipeline notebook batch
# Edit RUN_CELL* flags in tenure/540_tenure_pipeline.ipynb CELL 0 first!
sbatch pipe_job.slurm
./scripts/track_slurm.sh      # or ./scripts/track_slurm.sh JOBID
```

---

## 4. OpenAlex bulk snapshot (external to zip)

This handoff includes **`openalex_snapshot_cache.jsonl`** (~1 MB partial) and **`openalex_works_by_year.jsonl`** from Charles's run. For a **full** rebuild or new schools, you need the UVA CDH snapshot on Rivanna:

```text
~/cdh/OpenAlex1125/publicationauthoraffiliation/*.csv.gz
~/cdh/OpenAlex1125/pub2year.csv.gz
```

See `tenure/documents/HPC_SETUP_CHECKLIST.md` § OpenAlex / CDH.

Override path if needed:

```bash
export OPENALEX_SNAPSHOT_ROOT=/your/path/to/OpenAlex1125
sbatch build_openalex_cache.slurm
```

---

## 5. Cursor Remote-SSH workflow

Charles's notes: **`tenure/documents/RIVANNA_CURSOR_REMOTE_SSH_FOR_DUMMIES.md`** and **`HPC_SETUP_CHECKLIST.md`**.

Summary: VPN → Remote-SSH to Rivanna → open **workspace root** folder → run notebook or submit Slurm from integrated terminal.

---

## 6. Internet Archive / CDX from compute nodes

**Login node:** CDX queries (Cell 3A) and HTML download (Cell 3B) work.  
**Compute nodes (Slurm batch):** outbound HTTP to `web.archive.org` may be **blocked**.

**Practical rule:** Run Wayback scrape cells **interactively on login node** or Mac; use `pipe_job.slurm` for heavy offline stages (OpenAlex cache, panel build) after data exists.

---

## 7. Helper scripts included

| Script | Run from workspace root |
|--------|-------------------------|
| `./apply_url_updates.sh` | Apply URL worksheet edits |
| `./scripts/track_slurm.sh [JOBID]` | Tail Slurm `.err` log |
| `python tenure/run_stage3b_cli.py` | Wayback download outside Jupyter |

---

## 8. Checklist before first pipe_job

- [ ] `#SBATCH --mail-user` and `--account` updated in all three `.slurm` files
- [ ] `conda activate tenure_net` works
- [ ] `papermill` installed (`pip install papermill`)
- [ ] `tenure/540_tenure_pipeline.ipynb` CELL 0 paths print sensible `WORKSPACE_ROOT`
- [ ] `RUN_CELL*` flags set intentionally (don't accidentally re-scrape everything)
- [ ] OpenAlex: cache file present OR CDH snapshot mounted for 6B rebuild
