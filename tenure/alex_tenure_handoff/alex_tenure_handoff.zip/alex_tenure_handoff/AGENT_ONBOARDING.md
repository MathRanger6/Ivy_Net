# LLM agent onboarding — tenure pipeline handoff

**Audience:** An AI coding agent (Cursor, Claude, etc.) helping **Alex Gates** operate this pipeline.  
**Human reader:** Alex — point your agent at this file first.

**Questions channel:** Alex may email **Charles Levine** with *any* question about this pipeline — setup, data paths, science, code, Rivanna, or interpretation. Charles will relay those questions to **PEER** (the tenure-pipeline AI agent that built this handoff) and return answers. When stuck, **email Charles rather than guessing.**

---

## Mission

Reproduce and extend Charles Levine's **R1 CS faculty tenure pipeline**:

1. **Scrape** archived faculty rosters from the Wayback Machine (168 schools, 2000–2024)
2. **Parse** HTML → names/ranks
3. **Link** people longitudinally within each department
4. **Match** to OpenAlex publications
5. **Build** leave-one-out peer-pool quality metrics
6. **Analyze** preliminary tenure vs. productivity (Stage 9; Cox Layer B not yet wired)

This zip contains **code, docs, config, and schema examples**. The **full multi-GB dataset** lives on **UVA Rivanna** under Charles's home (`dzk3ja/Ivy_Net/`). **Alex may not have read access yet** — see **`RIVANNA_DATA_PATHS.md`** for the file catalog and Options A–D (permissions, copy, rsync, rebuild). Do not assume Rivanna paths work until Charles confirms.

---

## CRITICAL — where the real data lives

| Resource | Path on Rivanna |
|----------|-----------------|
| **All pipeline JSONL + HTML** | `/sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/tenure/tenure_pipeline/` (**Charles's tree — access TBD for Alex**) |
| **OpenAlex CDH snapshot** | `~/cdh/OpenAlex1125/` (UVA CDH — separate access) |
| **DBLP XML** | `.../Ivy_Net/python_packages/dblp-parser/dblp.xml` |

**Do not symlink** to Charles's tree until access is arranged. See **`RIVANNA_DATA_PATHS.md`** Options A–D.

**Schema only in zip:** `examples/*.sample` — do **not** set CELL 0 paths to `examples/`.

---

## Workspace layout (non-negotiable)

**Workspace root** = directory containing **`functionsG_working.py`**.

```text
<workspace_root>/
├── functionsG_working.py          ← REQUIRED import target (Cell 0)
├── RIVANNA_DATA_PATHS.md          ← FULL DATA MAP (read first)
├── AGENT_ONBOARDING.md            ← this file
├── examples/                      ← schema samples ONLY
├── environment-tenure_net.yml
├── apply_url_updates.sh
├── pipe_job.slurm
├── build_openalex_cache.slurm
├── scripts/track_slurm.sh
├── slurm/myjob.slurm
└── tenure/
    ├── 540_tenure_pipeline.ipynb  ← main conductor
    ├── 543_package_panel.ipynb
    ├── run_stage3b_cli.py
    ├── documents/
    └── tenure_pipeline/           ← .py + small config; DATA via symlink/rsync
```

**Do not** flatten this tree. **`540` CELL 0** sets `TENURE_PIPELINE_DIR = WORKSPACE_ROOT / "tenure" / "tenure_pipeline"`.

---

## Dependency audit (what to import)

### Required at workspace root

| File | Used by |
|------|---------|
| `functionsG_working.py` | CELL 0, 1; `openalex_resolver.py` (`tyme`, timing, json helpers) |

There is **no** `functionsA.py` / `functionsH.py` for this pipeline. A duplicate `functionsG_working.py` exists under `tenure/tenure_pipeline/` — **ignore it**; imports resolve to workspace root via `sys.path`.

### Python package: `tenure/tenure_pipeline/*.py`

| Module | Stage | Role |
|--------|-------|------|
| `r1_schools_data.py` | 2 | 168-school definitions (`PILOT_SCHOOLS`) |
| `html_parser.py` | 4 | Multi-strategy faculty page parser |
| `faculty_linker.py` | 5 | Longitudinal panel + Wayback metadata join |
| `openalex_resolver.py` | 6A–6B | Author ID + works-by-year |
| `build_openalex_cache.py` | 6B | Rivanna CDH bulk scan (standalone + Slurm) |
| `panel_builder.py` | 7 | Enriched panel + tenure/attrition events |
| `pool_metrics.py` | 8 | LOO peer-pool quality |
| `stage9_analysis.py` | 9 | Binned inverted-U check |
| `apply_url_updates.py` | 3 | URL worksheet apply + Option B paths |
| `discover_faculty_urls.py` | 3 | CDX wildcard URL discovery for low-quality schools |
| `viz_pipeline.py` | 3–9 viz | Stage summary plots |
| `stage6_pilot.py` | 6 | Coverage-first school ordering |
| `rebuild_plan.py`, `legacy_flat_snapshots.py` | 3 | Plan/HTML maintenance utilities |

### Shell helpers

| Script | Calls |
|--------|-------|
| `apply_url_updates.sh` | `tenure/tenure_pipeline/apply_url_updates.py` |
| `scripts/track_slurm.sh` | tails `slurm_out/slurm-*.err` |
| `tenure/run_stage3b_cli.py` | executes CELL 0 + 3B from notebook JSON |

### Conda environment

`environment-tenure_net.yml` — create with `mamba env create -f environment-tenure_net.yml`.

**Also install for Slurm batch runs:** `pip install papermill` (not always in yml).

### External data NOT in zip

| Resource | Location | Needed for |
|----------|----------|------------|
| UVA CDH OpenAlex full snapshot | `~/cdh/OpenAlex1125/` on Rivanna | Full Cell 6B bulk rebuild |
| `.env` | workspace root (create from `.env.example`) | `OPENALEX_EMAIL` for API fallback |

---

## Agent playbook: first session

### Step 1 — Read docs (in order)

1. **`RIVANNA_DATA_PATHS.md`** — verify Charles's data paths; set up symlink if needed
2. `README_HANDOFF.md`
3. `tenure/documents/20260720_Preliminary_Pipeline_Feasibility_Memo_for_Alex_Gates.md`
4. `tenure/documents/TENURE_PIPELINE_OVERVIEW.md`
5. `slurm/RIVANNA_SETUP_FOR_ALEX.md`

### Step 2 — Check Rivanna data access (when ready)

```bash
RIV="/sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/tenure/tenure_pipeline"
ls "$RIV/faculty_panel_with_pools.jsonl"   # OK if Charles granted access; "Permission denied" is expected until then
```

If denied: use **`examples/`** for schema; read **`RIVANNA_DATA_PATHS.md`**; **email Charles** with needed files from the catalog. Do not hack around permissions.

### Step 3 — Verify environment

```bash
cd <workspace_root>
conda activate tenure_net
python -c "from functionsG_working import tyme; import html_parser, faculty_linker, openalex_resolver; print('imports OK')"
```

If imports fail, check `sys.path` matches CELL 0 (workspace root must be cwd or on path).

### Step 4 — Open notebook, run CELL 0 only

File: `tenure/540_tenure_pipeline.ipynb`

Confirm printed paths:

- `WORKSPACE_ROOT` → handoff root
- `TENURE_PIPELINE_DIR` → `.../tenure/tenure_pipeline`
- Existing artifacts detected (plan jsonl, panel jsonl, etc.)

### Step 5 — Respect RUN_CELL flags

**Never set all RUN_CELL=True blindly** on a full checkpoint — you may re-download 34K HTML files.

Safe defaults when **continuing from Charles's data**:

```python
RUN_CELL1  = False   # DBLP already parsed (partial dblp_parsed/ included)
RUN_CELL2  = False
RUN_CELL3_CDX      = False
RUN_CELL3_DOWNLOAD = False
RUN_CELL4  = False
RUN_CELL5  = False
RUN_CELL6A = False   # set True only to refresh author IDs for new schools
RUN_CELL6B = False   # set True with cache/CDH for new authors
RUN_CELL7  = True    # rebuild enriched panel if upstream changed
RUN_CELL8  = True
RUN_CELL9  = True
```

To **re-scrape from scratch**, see gameplan reset instructions in `TENURE_DATA_GAMEPLAN.md` (delete plan/index/HTML in order).

---

## Key data artifacts (on Rivanna — not in zip)

| File | ~Size | Grain |
|------|-------|-------|
| `faculty_snapshots/` | 2.2 GB | Raw Wayback HTML |
| `faculty_panel.jsonl` | 1.7 GB | Snapshot-level panel |
| `faculty_panel_with_pools.jsonl` | 72 MB | **Analysis grain** (~106.6K person-years) |
| `faculty_snapshots_parsed.jsonl` | 846 MB | Parsed name/rank rows |

**Examples in zip:** `examples/*.sample` — same schema, truncated.

**Panel grain trap:** `faculty_panel.jsonl` has ~2.56M rows (multiple Wayback captures per person-year). Analysis uses collapsed `faculty_panel_with_pools.jsonl`.

---

## Common agent tasks

| User ask | Action |
|----------|--------|
| "Re-run analysis only" | CELL 0 → RUN_CELL7–9 True, rest False |
| "Add a new school" | Edit `r1_schools_data.py` + CSV; RUN_CELL2, 3A–5, 6A–6B for that school |
| "Fix bad parse for school X" | `DISCOVER_FACULTY_URLS_GUIDE.md`; `discover_faculty_urls.py`; `apply_url_updates.sh` |
| "Run on Rivanna" | Edit Slurm `#SBATCH` lines; `sbatch slurm/myjob.slurm` then `pipe_job.slurm` |
| "Export for advisor" | `543_package_panel.ipynb` → `R1_tenure_data.csv` |

---

## Binding scientific rules (do not conflate)

From Charles's dissertation architecture:

1. **Environment** (peer pool / congestion) ≠ **advancement** (tenure outcome)
2. **Score** (e.g. LOO pool quality) ≠ **select** (tenure decision) — separate steps
3. Stage 9 is **descriptive** binned check; **Cox survival (Cells 10–12) is planned, not wired**

---

## What not to do

- Do not move `functionsG_working.py` without updating CELL 0 path walk logic
- Do not commit multi-GB JSONL to git if Alex creates a repo — use `.gitignore` patterns from Charles's repo
- Do not hand-merge OpenAlex IDs for a convenience subset (bias)
- Do not describe Stage 9 as causal inference or Cox as complete

---

## Human escalation

Charles Levine authored the pipeline; feasibility memo and internal notes in `tenure/documents/`.

**When Alex or this agent is unsure:** do not invent paths, flags, or scientific claims. Alex should **email Charles any question** — Charles will ask **PEER** to answer and will reply to Alex. That includes Rivanna access, symlink setup, `RUN_CELL*` choices, OpenAlex tiers, and what is safe to re-run.

When Alex's intent conflicts with `TENURE_DATA_GAMEPLAN.md`, ask Alex (via email to Charles if needed) before changing stage boundaries or artifact names.
