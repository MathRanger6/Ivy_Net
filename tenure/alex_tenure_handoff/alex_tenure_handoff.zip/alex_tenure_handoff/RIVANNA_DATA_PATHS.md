# Rivanna data paths — full pipeline artifacts

**For Alex and LLM agents.** This handoff zip contains **code + docs + small examples only**. Charles's **full dataset** lives on UVA Rivanna under his home directory. **Alex does not automatically have read access to `/sfs/gpfs/tardis/home/dzk3ja/`** — Charles and Alex will decide later whether to grant permissions, copy files, or have Alex rebuild from the code. **Until then, treat the paths below as a catalog of what exists, not as paths Alex can use today.**

---

## Access status (read this first)

| Status | Meaning |
|--------|---------|
| **In OneDrive zip** | Code, docs, config, `examples/` — Alex has this now |
| **On Rivanna (`dzk3ja/`)** | Charles's full checkpoint — **access TBD** |
| **Questions** | Alex emails Charles → Charles asks **PEER** → reply |

**Do not assume** symlink or rsync to `dzk3ja/Ivy_Net` will work until Charles confirms. If `ls` on those paths fails with "Permission denied," that is expected — email Charles with what you need.

---

## Charles's canonical Rivanna locations (reference)

These are where **Charles's copy** of the data lives today:

| What | Absolute path on Rivanna |
|------|--------------------------|
| **Repo / workspace root** | `/sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/` |
| **Pipeline data directory** | `/sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/tenure/tenure_pipeline/` |
| **Main notebook (Charles's)** | `.../Ivy_Net/tenure/540_tenure_pipeline.ipynb` |
| **OpenAlex CDH snapshot** | `~/cdh/OpenAlex1125/` (under Charles's account; UVA CDH — separate access request) |
| **DBLP XML (Cell 1)** | `.../Ivy_Net/python_packages/dblp-parser/dblp.xml` (~5 GB) |

---

## Full artifacts by stage (under Charles's `tenure/tenure_pipeline/`)

Use this table to **tell Charles which files you need** when planning a data transfer.

| File / folder | ~Size | Stage | Need it to… |
|---------------|------:|-------|-------------|
| `faculty_snapshots/` | **2.2 GB** | 3B | Re-parse or audit HTML (full scrape checkpoint) |
| `faculty_snapshots_plan.jsonl` | 15 MB | 3A | Resume Wayback plan without re-CDX |
| `faculty_snapshots_index.jsonl` | 18 MB | 3B | Download audit |
| `faculty_snapshots_parsed.jsonl` | 846 MB | 4 | Skip re-parse; rebuild panel from parse |
| `faculty_snapshots_strategy_audit.jsonl` | 25 MB | 4 | Parser QA |
| `faculty_panel.jsonl` | **1.7 GB** | 5 | Raw snapshot-level panel |
| `faculty_panel_enriched.jsonl` | 55 MB | 7 | Skip Cells 6–7 if unchanged |
| `faculty_panel_with_pools.jsonl` | **72 MB** | 8 | **Run analysis (Stages 8–9)** — smallest useful analysis checkpoint |
| `openalex_author_ids.jsonl` | 7 MB | 6A | OpenAlex-linked analysis |
| `openalex_works_by_year.jsonl` | 22 MB | 6B | Publication counts |
| `openalex_snapshot_cache.jsonl` | varies | 6B | Fast 6B re-run |
| `openalex_inst_map.json` | small | 6A | **Already in zip** |
| `R1_tenure_data.csv` | 20 MB | 543 | Advisor-style export |
| `dblp_parsed/dblp_*.jsonl` | multi-GB | 1 | DBLP spine experiments |
| `stage9_binned_table.csv` | small | 9 | **Example in zip** |

**Minimal set to continue analysis without re-scraping:**  
`faculty_panel_with_pools.jsonl` (+ optionally `openalex_author_ids.jsonl`, `openalex_works_by_year.jsonl`).

**Minimal set to extend scrape/parse:**  
`faculty_snapshots_plan.jsonl`, `faculty_snapshots_index.jsonl`, `faculty_snapshots/` (or re-run Cells 3A–3B from code).

---

## Options when Alex needs Rivanna data (decide with Charles)

### Option A — Group / ACL access to Charles's tree

Charles grants Alex read access to some or all of `.../Ivy_Net/tenure/tenure_pipeline/`. Then symlink from Alex's handoff clone:

```bash
cd ~/alex_tenure_handoff/tenure
ln -s /sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/tenure/tenure_pipeline tenure_pipeline
```

**Pros:** No duplicate storage. **Cons:** Requires Rivanna admin or group setup; Charles must approve scope.

### Option B — Charles copies a subset to Alex's Rivanna home

Charles (or Alex with Charles's help) copies only needed files, e.g.:

```bash
# Illustrative — run from a context where dzk3ja paths are readable
DEST=~/alex_tenure_handoff/tenure/tenure_pipeline
mkdir -p "$DEST"
cp /sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/tenure/tenure_pipeline/faculty_panel_with_pools.jsonl "$DEST/"
# add more files per table above
```

**Pros:** Alex owns the copy. **Cons:** Uses Alex's quota; must pick files deliberately.

### Option C — rsync over SSH (if Alex gets read access to Charles's account or shared staging)

```bash
RSYNC="rsync -avz --progress"
SRC="dzk3ja@rivanna.hpc.virginia.edu:/sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/tenure/tenure_pipeline/"

# Analysis-only (~100 MB):
$RSYNC "${SRC}faculty_panel_with_pools.jsonl" ~/alex_tenure_handoff/tenure/tenure_pipeline/
$RSYNC "${SRC}openalex_author_ids.jsonl" ~/alex_tenure_handoff/tenure/tenure_pipeline/
$RSYNC "${SRC}openalex_works_by_year.jsonl" ~/alex_tenure_handoff/tenure/tenure_pipeline/
```

**Pros:** Resumable, selective. **Cons:** Requires SSH/rsync permission to source path.

### Option D — No data transfer: rebuild from code

Alex unzips handoff on Rivanna, runs Cells 2–5 (and 3A–3B for Wayback) to produce fresh artifacts under **his own** `tenure/tenure_pipeline/`. OpenAlex CDH may still need separate UVA access.

**Pros:** Fully independent. **Cons:** Wayback re-scrape takes time; may duplicate Charles's work.

**Charles + Alex:** pick A/B/C/D (or a mix) when Alex knows his goals. Email Charles with the rows you need from the table above.

---

## What Alex can do now (OneDrive zip only)

- Read **`AGENT_ONBOARDING.md`** and pipeline docs
- Inspect **`examples/*.sample`** for JSONL/HTML schema
- Set up **`tenure_net`** conda env locally or on Rivanna (`slurm/myjob.slurm`)
- Edit **`540_tenure_pipeline.ipynb`** CELL 0 flags and understand stage flow
- **Not yet:** run Cells 3+ end-to-end without Rivanna data or a fresh scrape

---

## Examples in this zip (`examples/`)

Truncated samples only — see **`examples/README.md`**. Same schema as production files listed above.

---

## OpenAlex CDH (separate from `dzk3ja/`)

Bulk Cell 6B can read UVA Connected Data Hub (each user requests access):

```text
~/cdh/OpenAlex1125/publicationauthoraffiliation/*.csv.gz
~/cdh/OpenAlex1125/pub2year.csv.gz
```

Charles's partial cache path (if ever shared):  
`.../Ivy_Net/tenure/tenure_pipeline/openalex_snapshot_cache.jsonl`

---

## Verify data is reachable (after Charles grants access or copy)

```bash
RIV="/sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/tenure/tenure_pipeline"
ls -lh "$RIV/faculty_panel_with_pools.jsonl"   # may fail until access is arranged
```

If this fails, use **`examples/`** for schema reference and **email Charles** with needed files from the table above.

---

## What stays in the zip

- All `tenure/tenure_pipeline/*.py` modules
- Config CSVs: `r1_cs_departments.csv`, `url_update_worksheet.csv`, `r1_schools_data.py`
- Notebooks, Slurm scripts, documentation, `examples/`

**Large JSONL and HTML are not in the zip** — they remain on Charles's Rivanna tree until you jointly choose Option A–D.
