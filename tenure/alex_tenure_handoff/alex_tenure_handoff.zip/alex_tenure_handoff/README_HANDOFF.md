# Tenure pipeline handoff — Alex Gates

**Prepared:** August 2026 · **From:** Charles Levine  
**Package size:** ~5.5 MB zipped (code + docs + **examples** — not full data)

---

## Start here

| Reader | File |
|--------|------|
| **Alex (human)** | This file → **`RIVANNA_DATA_PATHS.md`** → `slurm/RIVANNA_SETUP_FOR_ALEX.md` |
| **LLM agent** | **`AGENT_ONBOARDING.md`** first |

**Stuck?** Email Charles **any question** — Charles asks **PEER** (the pipeline agent) and replies. Don't guess on paths or permissions.

---

## OneDrive package (you have this now)

Unzip **`alex_tenure_handoff`** — everything needed to **read, configure, and eventually run** the pipeline code. It includes schema **`examples/`** but **not** the multi-GB Rivanna dataset.

---

## Rivanna data (separate — access TBD)

Charles's full checkpoint lives at:

```text
/sfs/gpfs/tardis/home/dzk3ja/Ivy_Net/tenure/tenure_pipeline/
```

**You may not have read access to `dzk3ja/` yet.** That is expected. See **`RIVANNA_DATA_PATHS.md`** for:

- A catalog of every artifact and its size  
- **Options A–D** when you're ready (shared permissions, copy subset, rsync, or rebuild from code)  
- Which minimal files suffice for analysis vs re-scrape  

Charles and Alex will decide transfer strategy together — email Charles with what you need from the catalog.

---

## Key docs

1. **`RIVANNA_DATA_PATHS.md`** — data catalog + access options (agent-critical)
2. **`AGENT_ONBOARDING.md`** — LLM agent playbook
3. `tenure/documents/TENURE_PIPELINE_OVERVIEW.md`
4. `tenure/documents/20260720_Preliminary_Pipeline_Feasibility_Memo_for_Alex_Gates.pdf`

---

## Contact

**Alex → Charles → PEER.** Email Charles any pipeline question; he relays to PEER and sends the answer back.

Charles Levine — data access planning, scientific intent, Layer B (Cox) status.
